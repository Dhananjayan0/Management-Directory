import React, { useState } from 'react';
import { Employee } from './types/Employee';
import { useEmployees } from './hooks/useEmployees';
import { Header } from './components/Header';
import { EmployeeFilters } from './components/EmployeeFilters';
import { EmployeeGrid } from './components/EmployeeGrid';
import { Pagination } from './components/Pagination';
import { Modal } from './components/ui/Modal';
import { EmployeeForm } from './components/EmployeeForm';

function App() {
  const {
    employees,
    totalEmployees,
    filterCriteria,
    sortCriteria,
    currentPage,
    totalPages,
    itemsPerPage,
    setFilterCriteria,
    setSortCriteria,
    setCurrentPage,
    setItemsPerPage,
    addEmployee,
    updateEmployee,
    deleteEmployee,
    getEmployeeById
  } = useEmployees();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | undefined>();

  const handleAddEmployee = () => {
    setEditingEmployee(undefined);
    setIsModalOpen(true);
  };

  const handleEditEmployee = (employee: Employee) => {
    setEditingEmployee(employee);
    setIsModalOpen(true);
  };

  const handleDeleteEmployee = (employee: Employee) => {
    deleteEmployee(employee.id);
  };

  const handleSaveEmployee = (employeeData: any) => {
    if (editingEmployee) {
      updateEmployee(editingEmployee.id, employeeData);
    } else {
      addEmployee(employeeData);
    }
    setIsModalOpen(false);
    setEditingEmployee(undefined);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingEmployee(undefined);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header onAddEmployee={handleAddEmployee} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          {/* Filters */}
          <EmployeeFilters
            filterCriteria={filterCriteria}
            sortCriteria={sortCriteria}
            onFilterChange={setFilterCriteria}
            onSortChange={setSortCriteria}
            totalEmployees={totalEmployees}
            showingEmployees={employees.length}
          />

          {/* Employee Grid */}
          <EmployeeGrid
            employees={employees}
            onEdit={handleEditEmployee}
            onDelete={handleDeleteEmployee}
          />

          {/* Pagination */}
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            itemsPerPage={itemsPerPage}
            totalItems={totalEmployees}
            onPageChange={setCurrentPage}
            onItemsPerPageChange={setItemsPerPage}
          />
        </div>
      </main>

      {/* Add/Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        title={editingEmployee ? 'Edit Employee' : 'Add New Employee'}
        size="lg"
      >
        <EmployeeForm
          employee={editingEmployee}
          onSave={handleSaveEmployee}
          onCancel={handleCloseModal}
        />
      </Modal>
    </div>
  );
}

export default App;