import { Employee } from '../types/Employee';

export const mockEmployees: Employee[] = [
  {
    id: 1,
    firstName: 'John',
    lastName: 'Doe',
    email: 'john.doe@company.com',
    department: 'Engineering',
    role: 'Senior Developer',
    joinDate: '2023-01-15',
    phone: '+1 (555) 123-4567'
  },
  {
    id: 2,
    firstName: 'Jane',
    lastName: 'Smith',
    email: 'jane.smith@company.com',
    department: 'Human Resources',
    role: 'HR Manager',
    joinDate: '2022-08-20',
    phone: '+1 (555) 234-5678'
  },
  {
    id: 3,
    firstName: 'Michael',
    lastName: 'Johnson',
    email: 'michael.johnson@company.com',
    department: 'Marketing',
    role: 'Marketing Specialist',
    joinDate: '2023-03-10',
    phone: '+1 (555) 345-6789'
  },
  {
    id: 4,
    firstName: 'Sarah',
    lastName: 'Wilson',
    email: 'sarah.wilson@company.com',
    department: 'Engineering',
    role: 'Frontend Developer',
    joinDate: '2023-05-22',
    phone: '+1 (555) 456-7890'
  },
  {
    id: 5,
    firstName: 'David',
    lastName: 'Brown',
    email: 'david.brown@company.com',
    department: 'Sales',
    role: 'Sales Representative',
    joinDate: '2022-11-30',
    phone: '+1 (555) 567-8901'
  },
  {
    id: 6,
    firstName: 'Emily',
    lastName: 'Davis',
    email: 'emily.davis@company.com',
    department: 'Finance',
    role: 'Financial Analyst',
    joinDate: '2023-02-14',
    phone: '+1 (555) 678-9012'
  },
  {
    id: 7,
    firstName: 'Robert',
    lastName: 'Miller',
    email: 'robert.miller@company.com',
    department: 'Engineering',
    role: 'DevOps Engineer',
    joinDate: '2022-12-05',
    phone: '+1 (555) 789-0123'
  },
  {
    id: 8,
    firstName: 'Lisa',
    lastName: 'Garcia',
    email: 'lisa.garcia@company.com',
    department: 'Design',
    role: 'UX Designer',
    joinDate: '2023-04-18',
    phone: '+1 (555) 890-1234'
  },
  {
    id: 9,
    firstName: 'Thomas',
    lastName: 'Anderson',
    email: 'thomas.anderson@company.com',
    department: 'Marketing',
    role: 'Content Manager',
    joinDate: '2023-01-08',
    phone: '+1 (555) 901-2345'
  },
  {
    id: 10,
    firstName: 'Maria',
    lastName: 'Rodriguez',
    email: 'maria.rodriguez@company.com',
    department: 'Human Resources',
    role: 'Recruiter',
    joinDate: '2022-09-12',
    phone: '+1 (555) 012-3456'
  },
  {
    id: 11,
    firstName: 'James',
    lastName: 'Taylor',
    email: 'james.taylor@company.com',
    department: 'Sales',
    role: 'Sales Manager',
    joinDate: '2022-07-25',
    phone: '+1 (555) 123-4560'
  },
  {
    id: 12,
    firstName: 'Amanda',
    lastName: 'White',
    email: 'amanda.white@company.com',
    department: 'Finance',
    role: 'Accountant',
    joinDate: '2023-06-01',
    phone: '+1 (555) 234-5601'
  }
];

export const departments = [
  'Engineering',
  'Human Resources',
  'Marketing',
  'Sales',
  'Finance',
  'Design'
];

export const roles = [
  'Senior Developer',
  'Frontend Developer',
  'DevOps Engineer',
  'HR Manager',
  'Recruiter',
  'Marketing Specialist',
  'Content Manager',
  'Sales Representative',
  'Sales Manager',
  'Financial Analyst',
  'Accountant',
  'UX Designer'
];