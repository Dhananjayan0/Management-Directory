import React from 'react';
import { FilterCriteria, SortCriteria } from '../types/Employee';
import { departments, roles } from '../data/mockData';
import { Search, Filter, SortAsc, SortDesc } from 'lucide-react';
import { Input } from './ui/Input';
import { Select } from './ui/Select';
import { Button } from './ui/Button';

interface EmployeeFiltersProps {
  filterCriteria: FilterCriteria;
  sortCriteria: SortCriteria;
  onFilterChange: (criteria: FilterCriteria) => void;
  onSortChange: (criteria: SortCriteria) => void;
  totalEmployees: number;
  showingEmployees: number;
}

export const EmployeeFilters: React.FC<EmployeeFiltersProps> = ({
  filterCriteria,
  sortCriteria,
  onFilterChange,
  onSortChange,
  totalEmployees,
  showingEmployees
}) => {
  const [showFilters, setShowFilters] = React.useState(false);

  const clearFilters = () => {
    onFilterChange({
      department: '',
      role: '',
      searchTerm: ''
    });
  };

  const hasActiveFilters = filterCriteria.department || filterCriteria.role || filterCriteria.searchTerm;

  return (
    <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
      {/* Search and Toggle */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search employees..."
            value={filterCriteria.searchTerm}
            onChange={(e) => onFilterChange({ ...filterCriteria, searchTerm: e.target.value })}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div className="flex items-center space-x-4">
          <Button
            variant="secondary"
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center space-x-2"
          >
            <Filter size={16} />
            <span>Filters</span>
            {hasActiveFilters && (
              <span className="bg-blue-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {[filterCriteria.department, filterCriteria.role, filterCriteria.searchTerm].filter(Boolean).length}
              </span>
            )}
          </Button>

          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-600">Sort:</span>
            <Select
              value={sortCriteria.field}
              onChange={(field) => onSortChange({ ...sortCriteria, field: field as keyof typeof sortCriteria })}
              options={[
                { value: 'firstName', label: 'First Name' },
                { value: 'lastName', label: 'Last Name' },
                { value: 'department', label: 'Department' },
                { value: 'role', label: 'Role' },
                { value: 'joinDate', label: 'Join Date' }
              ]}
              className="w-32"
            />
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onSortChange({ 
                ...sortCriteria, 
                direction: sortCriteria.direction === 'asc' ? 'desc' : 'asc' 
              })}
              className="p-2"
            >
              {sortCriteria.direction === 'asc' ? <SortAsc size={16} /> : <SortDesc size={16} />}
            </Button>
          </div>
        </div>
      </div>

      {/* Advanced Filters */}
      {showFilters && (
        <div className="mt-6 pt-6 border-t border-gray-200">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <Select
              label="Department"
              value={filterCriteria.department}
              onChange={(department) => onFilterChange({ ...filterCriteria, department })}
              options={[
                { value: '', label: 'All Departments' },
                ...departments.map(dept => ({ value: dept, label: dept }))
              ]}
            />

            <Select
              label="Role"
              value={filterCriteria.role}
              onChange={(role) => onFilterChange({ ...filterCriteria, role })}
              options={[
                { value: '', label: 'All Roles' },
                ...roles.map(role => ({ value: role, label: role }))
              ]}
            />

            <div className="flex items-end">
              <Button
                variant="secondary"
                onClick={clearFilters}
                disabled={!hasActiveFilters}
                className="w-full"
              >
                Clear Filters
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Results Summary */}
      <div className="mt-4 pt-4 border-t border-gray-100">
        <p className="text-sm text-gray-600">
          Showing {showingEmployees} of {totalEmployees} employees
          {hasActiveFilters && ' (filtered)'}
        </p>
      </div>
    </div>
  );
};