import React from 'react';
import { Employee } from '../types/Employee';
import { Mail, Phone, Calendar, Edit, Trash2 } from 'lucide-react';
import { Button } from './ui/Button';

interface EmployeeCardProps {
  employee: Employee;
  onEdit: (employee: Employee) => void;
  onDelete: (employee: Employee) => void;
}

export const EmployeeCard: React.FC<EmployeeCardProps> = ({
  employee,
  onEdit,
  onDelete
}) => {
  const handleDelete = () => {
    if (window.confirm(`Are you sure you want to delete ${employee.firstName} ${employee.lastName}?`)) {
      onDelete(employee);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200 p-6 border border-gray-200">
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">
            {employee.firstName} {employee.lastName}
          </h3>
          <p className="text-sm text-blue-600 font-medium">{employee.role}</p>
          <p className="text-sm text-gray-600">{employee.department}</p>
        </div>
        <div className="flex space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onEdit(employee)}
            className="p-2"
          >
            <Edit size={16} />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleDelete}
            className="p-2 text-red-600 hover:text-red-700 hover:bg-red-50"
          >
            <Trash2 size={16} />
          </Button>
        </div>
      </div>

      {/* Contact Information */}
      <div className="space-y-2">
        <div className="flex items-center text-sm text-gray-600">
          <Mail size={14} className="mr-2 flex-shrink-0" />
          <span className="truncate">{employee.email}</span>
        </div>
        <div className="flex items-center text-sm text-gray-600">
          <Phone size={14} className="mr-2 flex-shrink-0" />
          <span>{employee.phone}</span>
        </div>
        <div className="flex items-center text-sm text-gray-600">
          <Calendar size={14} className="mr-2 flex-shrink-0" />
          <span>Joined {new Date(employee.joinDate).toLocaleDateString()}</span>
        </div>
      </div>

      {/* Employee ID */}
      <div className="mt-4 pt-4 border-t border-gray-100">
        <span className="text-xs text-gray-500">ID: {employee.id}</span>
      </div>
    </div>
  );
};