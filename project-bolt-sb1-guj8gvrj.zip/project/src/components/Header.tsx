import React from 'react';
import { Users, Plus } from 'lucide-react';
import { Button } from './ui/Button';

interface HeaderProps {
  onAddEmployee: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onAddEmployee }) => {
  return (
    <div className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-6">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-600 p-2 rounded-lg">
              <Users className="text-white" size={24} />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Employee Directory</h1>
              <p className="text-gray-600">Manage your organization's employees</p>
            </div>
          </div>
          
          <Button onClick={onAddEmployee} className="flex items-center space-x-2">
            <Plus size={16} />
            <span>Add Employee</span>
          </Button>
        </div>
      </div>
    </div>
  );
};