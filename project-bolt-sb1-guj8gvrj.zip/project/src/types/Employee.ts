export interface Employee {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  department: string;
  role: string;
  joinDate: string;
  phone: string;
}

export interface EmployeeFormData {
  firstName: string;
  lastName: string;
  email: string;
  department: string;
  role: string;
  phone: string;
}

export interface FilterCriteria {
  department: string;
  role: string;
  searchTerm: string;
}

export interface SortCriteria {
  field: keyof Employee;
  direction: 'asc' | 'desc';
}