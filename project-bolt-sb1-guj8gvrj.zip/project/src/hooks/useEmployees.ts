import { useState, useMemo } from 'react';
import { Employee, FilterCriteria, SortCriteria, EmployeeFormData } from '../types/Employee';
import { mockEmployees } from '../data/mockData';

export const useEmployees = () => {
  const [employees, setEmployees] = useState<Employee[]>(mockEmployees);
  const [filterCriteria, setFilterCriteria] = useState<FilterCriteria>({
    department: '',
    role: '',
    searchTerm: ''
  });
  const [sortCriteria, setSortCriteria] = useState<SortCriteria>({
    field: 'firstName',
    direction: 'asc'
  });
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(12);

  // Filter and sort employees
  const filteredAndSortedEmployees = useMemo(() => {
    let filtered = employees.filter(employee => {
      const matchesSearch = !filterCriteria.searchTerm || 
        `${employee.firstName} ${employee.lastName}`.toLowerCase().includes(filterCriteria.searchTerm.toLowerCase()) ||
        employee.email.toLowerCase().includes(filterCriteria.searchTerm.toLowerCase());
      
      const matchesDepartment = !filterCriteria.department || employee.department === filterCriteria.department;
      const matchesRole = !filterCriteria.role || employee.role === filterCriteria.role;
      
      return matchesSearch && matchesDepartment && matchesRole;
    });

    // Sort employees
    filtered.sort((a, b) => {
      const aValue = a[sortCriteria.field];
      const bValue = b[sortCriteria.field];
      
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        const comparison = aValue.localeCompare(bValue);
        return sortCriteria.direction === 'asc' ? comparison : -comparison;
      }
      
      if (typeof aValue === 'number' && typeof bValue === 'number') {
        const comparison = aValue - bValue;
        return sortCriteria.direction === 'asc' ? comparison : -comparison;
      }
      
      return 0;
    });

    return filtered;
  }, [employees, filterCriteria, sortCriteria]);

  // Paginate employees
  const paginatedEmployees = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return filteredAndSortedEmployees.slice(startIndex, endIndex);
  }, [filteredAndSortedEmployees, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(filteredAndSortedEmployees.length / itemsPerPage);

  const addEmployee = (employeeData: EmployeeFormData) => {
    const newEmployee: Employee = {
      ...employeeData,
      id: Math.max(...employees.map(e => e.id)) + 1,
      joinDate: new Date().toISOString().split('T')[0]
    };
    setEmployees(prev => [...prev, newEmployee]);
    setCurrentPage(1); // Reset to first page
  };

  const updateEmployee = (id: number, employeeData: EmployeeFormData) => {
    setEmployees(prev => prev.map(emp => 
      emp.id === id ? { ...emp, ...employeeData } : emp
    ));
  };

  const deleteEmployee = (id: number) => {
    setEmployees(prev => prev.filter(emp => emp.id !== id));
    
    // Adjust current page if necessary
    const newTotalPages = Math.ceil((filteredAndSortedEmployees.length - 1) / itemsPerPage);
    if (currentPage > newTotalPages && newTotalPages > 0) {
      setCurrentPage(newTotalPages);
    }
  };

  const getEmployeeById = (id: number): Employee | undefined => {
    return employees.find(emp => emp.id === id);
  };

  return {
    employees: paginatedEmployees,
    totalEmployees: filteredAndSortedEmployees.length,
    filterCriteria,
    sortCriteria,
    currentPage,
    totalPages,
    itemsPerPage,
    setFilterCriteria,
    setSortCriteria,
    setCurrentPage,
    setItemsPerPage,
    addEmployee,
    updateEmployee,
    deleteEmployee,
    getEmployeeById
  };
};